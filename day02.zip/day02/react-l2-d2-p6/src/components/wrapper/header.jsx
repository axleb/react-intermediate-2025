import logo from "./../../assets/chart.gif";
import { NavLink } from "react-router-dom";
import {useContext, useState, useCallback} from "react";
import {AuthContext} from "./../AuthContext";
import Popup from "./popup";
//
function Header(){
  const { user, logout } = useContext(AuthContext);
  const [showPopup, setShowPopup] = useState(false);

  const handleLogoutClick = useCallback(() => {
    setShowPopup(true);
  }, []);

  const handleConfirmLogout = useCallback(() => {
    logout();
    setShowPopup(false);
  }, [logout]);

  const handleCancelLogout = useCallback(() => {
    setShowPopup(false);
  }, []);

  return (
    <header>
      <img src={logo} id="logo" />
      <h1><a href="index.html">Skillsoft Weight Tracker</a></h1>
      <nav>
        <ul>
          <li><NavLink to="/">home</NavLink></li>
          <li><NavLink to="/register">register</NavLink></li>
          <li><NavLink to="/employees">employees</NavLink></li>
          <li><NavLink to="/enterweight">enter weight</NavLink></li>
          { !user ? (
            <li className="has-dropdown" >
              <NavLink to="/login" >login &#x25BE;</NavLink>
              <div className="nav-dropdown" >
                <NavLink to="/login">User Login</NavLink>
                <NavLink to="/admin-login" className="admin-option">Admin Login</NavLink>
              </div>
            </li>
          ) : (
            <>
              {user.role === 'admin' && <li><NavLink to="/admin">Admin Panel</NavLink></li>}
              <li onClick={handleLogoutClick}>{user.username}</li>
            </>
          ) }
        </ul>
      </nav>
      { showPopup && (
        <Popup
          message="Are you sure you want to logout?"
          onConfirm={handleConfirmLogout}
          onCancel={handleCancelLogout}
        />
      ) }
    </header>
  );
};
//
export default Header;
