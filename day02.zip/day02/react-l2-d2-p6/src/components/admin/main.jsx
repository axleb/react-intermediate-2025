function Main(){
  return (
    <main>
      <h2>Admin Users Only</h2>
      <p>Calculate winner here ....</p>
    </main>
  )
};
//
export default Main;
