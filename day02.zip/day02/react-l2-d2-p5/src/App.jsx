import "./styles.css";
import Home from "./components/home/home";
import Employees from "./components/employees/employees";
import Register from "./components/register/register";
import Login from "./components/login/login";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { AuthProvider } from "./components/AuthContext.jsx";
import Enterweight from "./components/enterweight/enterweight";
//
function App() {
  return (
    <>
      <AuthProvider> 
        <BrowserRouter>
          <Routes>
            <Route path='/' element={<Home />} />
            <Route path='/employees' element={<Employees />} />
            <Route path='/register' element={<Register />} />
            <Route path="/login" element={<Login />} />
            <Route path='/enterweight' element={<Enterweight />} />
            {/* <Route path='/admin-login' element={<AdminLogin />} /> */}
          </Routes>
        </BrowserRouter>
      </AuthProvider>
    </>
  )
};
//
export default App;
