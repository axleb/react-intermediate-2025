function Popup({ message, onConfirm, onCancel } ) {
  return (
    <div className="popup-overlay">
      <div className="popup-content">
        <p>{message}</p>
        <div className="popup-actions">
          <button onClick={onCancel}>Cancel</button>
          <button onClick={onConfirm} className="popup-logout" >Logout</button>
        </div>
      </div>
    </div>
  );
};
export default Popup;
