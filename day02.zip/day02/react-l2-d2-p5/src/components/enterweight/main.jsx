import { useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../AuthContext";

function Main() {
  const [userweight, setUserWeight] = useState(null); // number or null
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState("");
  const navigate = useNavigate();
  const { user } = useContext(AuthContext);

  const formattedDate = new Date().toLocaleDateString('en-GB');

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError("");

    if (userweight === null || Number.isNaN(userweight)) {
      setError("Weight is required.");
      return;
    }
    if (userweight < 20 || userweight > 250) {
      setError("Weight must be between 20 and 250.");
      return;
    }

    setIsSubmitting(true);
    const payload = {
      id: user.id,
      weight: userweight, // send as number
      date: formattedDate
    };

    try {
      const response = await fetch('http://localhost:3030/weights', {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        if (response.status === 404) {
          throw new Error("Resource not found. The server endpoint may be incorrect.");
        }
        throw new Error(`Server error: ${response.status}`);
      }

      // success
      navigate("/");
    } catch (err) {
      console.log("An error occured! " + err.message);
      setIsSubmitting(false);
    }
  };

  return (
    <main>
      <h2>Enter your weight for today</h2>
      {user ? (
        <>
          <h2>Enter your weight for today</h2>
          <form onSubmit={handleSubmit}>
            <div>
              <label>
                Today’s weight:
                <input
                  type="number"
                  name="userweight"
                  min="20"
                  max="250"
                  step="1"
                  inputMode="decimal"
                  value={userweight ?? ''}
                  onChange={(e) => setUserWeight(e.target.valueAsNumber)}
                  onWheel={(e) => e.target.blur()}
                  disabled={isSubmitting}
                  required
                />
              </label>
            </div>
            {error && <p style={{ color: 'red' }}>{error}</p>}
            <button type="submit" disabled={isSubmitting}>
              Submit
            </button>
          </form>
        </>
      ) : (
        <h4>You must be logged in to post a weight</h4>
      )}

    </main>
  );
}

export default Main;
