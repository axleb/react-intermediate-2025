import { useState, useContext, useRef, useEffect  } from "react";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "./../AuthContext";
//
function Main() {
//
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loginStatus, setLoginStatus] = useState("");
  const navigate = useNavigate();
  const { login } = useContext(AuthContext);
  const focusUser = useRef(null);
//
  useEffect(() => {
    focusUser.current.focus();
  }, []);
//
  const handleFieldChange = (event) => {
    const { name, value } = event.target;
    if (name === "username") setUsername(value);
    if (name === "password") setPassword(value);
  };
  const handleSubmit = (event) => {
    event.preventDefault();
    fetch('http://localhost:3030/employees')
    .then(response => response.json())
    .then(users => {
      const found = users.find(
        user => user.username === username && user.password === password
      );
      if(found){
        setLoginStatus("Login Successful");
        login(found);
        navigate("/");
      } else {
        setLoginStatus("Invalid usernae or password");
      };
    })
    .catch( err => setLoginStatus("An error occured!" + err.message));
  };
//
  return (
    <main>
      <h2>Login to the competition</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>
            Name:
              <input 
              type="text" 
              name="username" 
              onChange={handleFieldChange} 
              
              />
          </label>
        </div>
        <div>
          <label>
            Password:
              <input 
              type="text" 
              name="password" 
              onChange={handleFieldChange} 
              ref={focusUser}
              />
          </label>
        </div>
        <div>
          <input type="submit" value="Submit" />
        </div>
      </form>
      {loginStatus && <p>{loginStatus}</p>}
    </main>
  );
};
//
export default Main;
