import { useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../AuthContext";
//
function Main() {
  const [userweight, setUserWeight] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState("");
  const navigate = useNavigate();
  const { user } = useContext(AuthContext);
  //
  const today = new Date();
  const day = String(today.getDate()).padStart(2, '0');
  const month = String(today.getMonth() + 1).padStart(2, '0');
  const year = today.getFullYear();
  const formattedDate = `${day}/${month}/${year}`;
  //
  const handleFieldChange = (event) => {
    const { name, value } = event.target;
    if (name === "userweight") setUserWeight(value);
  };
  const handleSubmit = async (event) => {
    event.preventDefault();
    setError("");
    const payload = {
      id: user.id,
      weight: String(userweight),
      date: formattedDate
    };
    if (userweight === "") {
      setError("Weight is required.");
      return;
    }
    const numWeight = Number(userweight);
    if (isNaN(numWeight)) {
      setError("Weight must be a number.");
      return;
    }
    if (numWeight < 20 || numWeight > 250) {
      setError("Weight must be between 20 and 250.");
      return;
    }



    // All validations passed, now submit the data
    setIsSubmitting(true);

    try{
      const response = await fetch('http://localhost:3030/weights', {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      })

      if (!response.ok) {
        if (response.status === 404) {
          throw new Error("Resource not found. The server endpoint may be incorrect.");
        }
        throw new Error(`Server error: ${response.status}`);
      }
      const text = await response.text();
      if (text) {
        JSON.parse(text); 
      }
      navigate("/");


    } catch(err){
      console.log("An error occured! " + err.message);
      setIsSubmitting(false);
    }
  };
  //
  return (
    <main>
      <h2>Enter your weight for today</h2>
      {user ? (
        <>
          <h2>Enter your weight for today</h2>
          <form onSubmit={handleSubmit}>
            <div>
              <label>
                Today’s weight:
                <input
                  type="text"
                  name="userweight"
                  onChange={handleFieldChange}
                />
              </label>
            </div>
            {error && <p style={{ color: 'red' }}>{error}</p>}
            <button type="submit" disabled={isSubmitting}>
              Submit
            </button>
          </form>
        </>
      ) : (
        <h4>You must be logged in to post a weight</h4>
      )}

    </main>
  );

};
//
export default Main;
