import { useState, useContext, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "./../AuthContext";
//
function Main() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loginStatus, setLoginStatus] = useState("");
  const navigate = useNavigate();
  const { login } = useContext(AuthContext);
  const focusUser = useRef(null); 
//
  useEffect(() => {
    focusUser.current.focus();
  }, []);
  //
  const handleFieldChange = (event) => {
    const { name, value } = event.target;
    if (name === "username") setUsername(value);
    if (name === "password") setPassword(value);
  };
  const handleSubmit = (event) => {
    event.preventDefault();
    fetch('http://localhost:3030/employees')
    .then(response => response.json())
    .then(users => {
      const found = users.find(
        user => user.username === username && user.password === password && user.role === 'admin'
      );
      if(found){
        setLoginStatus("Admin Login Successful");
        login(found);
        navigate("/admin");
      } else {
        setLoginStatus("Invalid admin credentials");
      }
    })
    .catch( err => setLoginStatus("An error occured!" + err.message));
  };
//
  return (
    <main>
      <h2>Admin Login</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>
            Name:
              <input 
              type="text" 
              name="username" 
              onChange={handleFieldChange} 
              ref={focusUser}
              />
          </label>
        </div>
        <div>
          <label>
            Password:
              <input 
              type="password" 
              name="password" 
              onChange={handleFieldChange} 
              />
          </label>
        </div>
        <div>
          <input type="submit" value="Login" />
        </div>
      </form>
       {loginStatus && <p>{loginStatus}</p>}
    </main>
  );
};
//
export default Main;
